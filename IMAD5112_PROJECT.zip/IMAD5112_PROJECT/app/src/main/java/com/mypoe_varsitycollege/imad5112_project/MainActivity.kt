package com.mypoe_varsitycollege.imad5112_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var add : Button
    private lateinit var subtract : Button
    private lateinit var multiply : Button
    private lateinit var divide : Button
    private lateinit var squareroot : Button
    private lateinit var power : Button
    private lateinit var answer : TextView
    private lateinit var number1 : EditText
    private lateinit var number2 : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        add = findViewById(R.id.add)
        subtract = findViewById(R.id.subtract)
        multiply = findViewById(R.id.multiply)
        divide = findViewById(R.id.divide)
        squareroot = findViewById(R.id.squareroot)
        power = findViewById(R.id.power)
        answer = findViewById(R.id.answer)
        number1 = findViewById(R.id.number1)
        number2 = findViewById(R.id.number2)

        add.setOnClickListener {
            val num1 = number1.text.toString()
            val num2 = number2.text.toString()
            val sum = num1.toInt() + num2.toInt()
            answer.text = "$num1 + $num2 = $sum"
        }
        subtract.setOnClickListener {
            val num1 = number1.text.toString()
            val num2 = number2.text.toString()
            val sum = num1.toInt() - num2.toInt()
            answer.text = "$num1 - $num2 = $sum"
        }
        divide.setOnClickListener {
            val num1Text = number1.text.toString()
            val num2Text = number2.text.toString()

            if (num2Text == "0") {
                answer.text = "Error: 0 cannot be the divisor"
            } else {
                try {
                    val num1 = num1Text.toInt()
                    val num2 = num2Text.toInt()
                    val sum = num1 / num2
                    answer.text = "$num1 / $num2 = $sum"
                } catch (e: NumberFormatException) {
                    answer.text = "Invalid input: Please enter valid numbers."
                }
            }
        }
        multiply.setOnClickListener {
            val num1 = number1.text.toString()
            val num2 = number2.text.toString()
            val sum = num1.toInt() * num2.toInt()
            answer.text = "$num1 * $num2 = $sum"
        }
        squareroot.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val sum: Double

            if (num1 < 0) {
                val imaginaryPart = Math.sqrt(-num1)
                answer.text = "sqrt($num1) = ${String.format("%.2f", imaginaryPart)}i"
            } else {
                sum = Math.sqrt(num1)
                answer.text = "sqrt($num1) = ${String.format("%.2f", sum)}"
            }
            power.setOnClickListener {
                val base = number1.text.toString().toDouble()
                val exponent = number2.text.toString().toInt()

                var result = 1.0 // Initialize result to 1

                var i = 0
                while (i < exponent) {
                    result *= base
                    i++
                }

                answer.text = "$base ^ $exponent = $result"
            }
        }
    }
}

//references
//JetBrains: Developer Tools for Professionals and Teams. (n.d.). Learn Kotlin With JetBrains Academy. [online] Available at: https://www.jetbrains.com/pages/academy/kotlin/?source=google&medium=cpc&campaign=14644130345&term=learn%20kotlin&content=545558206293&gad=1&gclid=CjwKCAjwgsqoBhBNEiwAwe5w0xYeDL2MoW5wgmWKGolucCHnTFA7SFkq3sd7XEVgtnmP9Q6N9FDXnhoCi7AQAvD_BwE [Accessed 26 Sep. 2023].
//Kotlin Help. (n.d.). Get started with Kotlin | Kotlin. [online] Available at: https://kotlinlang.org/docs/getting-started.html.